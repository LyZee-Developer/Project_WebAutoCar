package carAuto.carage.project_web_car;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectWebCarApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectWebCarApplication.class, args);
	}

}
