package carAuto.carage.project_web_car;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectWebCarApplicationTests {

	@Test
	void contextLoads() {
	}

}
